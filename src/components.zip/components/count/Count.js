import React, {Component} from 'react';

function Count({count}) {
    return (
        <div>
            <h1>{count}</h1>
        </div>
    );
}

export default Count;